<?
require_once 'operation_db.php';
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
require_once 'vendor/autoload.php';
    $key = 'example_key';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $input_values = $_POST["pin"];
    $pin  = combineValues($input_values);
$validationResult = validatePIN($pin);
if (!empty($validationResult)) {
// Ada pesan error, tampilkan pesan
     $msg = array("correct_pin" => $validationResult);

     $query= http_build_query($msg);

         // Redirect dengan menyisipkan data array dalam query string
         // header("Location: atm.php?" . $query_string);
     header("Location:pin.php?".$query);
     exit;	

} 
  
  if (isset($_COOKIE['jwt_cookie'])) {
    $jwt = $_COOKIE['jwt_cookie'];
	global $key;
    
    // Mendekode JWT
    try{
    $decoded = JWT::decode($jwt, new Key($key, 'HS256'));
    $num = $decoded -> NUMBER_CARD;
    $data = [      
	    'NUMBER_CARD' => $num,
    ];
     
    $result = $operation->checkIfExists($data);

    if ($result !== null ){ 
      
      if(isset($result['PIN']) && $result['PIN'] == $pin) {
      setout($num,$pin);

      }else{
      $msg = array("correct_pin" => 'gk cocok');

     $query= http_build_query($msg);

         // Redirect dengan menyisipkan data array dalam query string
         // header("Location: atm.php?" . $query_string);
     header("Location:pin.php?".$query);
     exit;
      }
    } else {

	try {
            $operation->insertDataUser(array_merge($data, ['PIN' => $pin]));
            setout($num,$pin);
        } catch (Exception $e) {
            $response = array("message" => "Terjadi kesalahan saat memasukkan data: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
            echo json_encode($response);
        }    
    }
	
    
  } catch (Exception $e) {
            $response = array("message" => "Terjadi kesalahan: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
            echo json_encode($response);
        }
                                                                                                             // Menutup koneksi
 } 
}
else {
 echo "pastikan menghunakan post";
}

function validatePIN($pin) {
    if (strlen($pin) !== 4) {
        return "Panjang PIN harus 4 digit.";
    } elseif (!ctype_digit($pin)) {
        return "PIN hanya boleh berisi digit angka.";
    } elseif (hasRepeatedDigits($pin)) {
        return "PIN tidak boleh berisi angka yang sama.";
    }
elseif (empty(hasSequentialPattern($pin))) {
        return "PIN tidak boleh berisi pola urutan.";
    }
    return ""; // PIN valid
}

function hasRepeatedDigits($input) {
    $digits = str_split($input);
    $uniqueDigits = array_unique($digits);
    
    return count($digits) !== count($uniqueDigits);
}


function hasSequentialPattern($input) {
    $len = strlen($input);

    for ($i = 0; $i < $len - 1; $i++) {
        if ($input[$i] + 1 != $input[$i + 1]) {
            return true;
        }
    }
    return false;

}



function combineValues($input_values) {
    // Menggabungkan semua nilai menjadi satu string dengan pemisah koma
    $combined_value = implode("", $input_values);
    return $combined_value;
}


function setout($num,$pin){
	global $key;
                                                                                                           $payload = [
                  'url' => 'main-menu',                                                                   'iss' => 'http://example.org',
                  'aud' => 'http://example.com',
                  'iat' => time(),
		  'exp' => time() + 3600,
		  'PIN' => $pin,
		  'NUMBER_CARD' => $num,
     ];

    //buat jwt
    $jwt = JWT::encode($payload, $key, 'HS256');
    setcookie("jwt_cookie", $jwt, time() +1200, "main-menu", false, true);                    // Sekarang $decoded berisi data yang telah didecode dari JWT
    header("Location:main-menu.php");

    }
?>
