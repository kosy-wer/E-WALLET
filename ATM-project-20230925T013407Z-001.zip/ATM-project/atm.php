<?php                                                                 // Mengimpor pustaka JWT yang diinstal melalui Composer  
require_once 'vendor/autoload.php';
// Menerima data dari request POST dan mengurai data JSON yang dikirim
use Firebase\JWT\JWT;
use Firebase\JWT\Key;



// Periksa apakah cookie dengan nama "jwt_cookie" ada
if (isset($_COOKIE['jwt_cookie'])) {
    $jwt = $_COOKIE['jwt_cookie'];
    
    
    // Ganti 'example_key' dengan kunci rahasia Anda
    
    $key = 'example_key';
    // Mendekode JWT
    $decoded = JWT::decode($jwt, new Key($key, 'HS256'));
if ($decoded->exp > time()) {
	
    $url = $decoded->url;
    //url ada payload benar arahkan ke pin.php
    header("Location:{$url}.php");
 }    
}



//cek query ada rspon tidak dari server
$showAlert = false;
if (isset($_GET['warning'])) {
    $isi = $_GET['warning'];
$showAlert = true;

}
?>

<!DOCTYPE html>
<html>
<head>
<style>
* {
  margin: 0;
  padding: 0;
}

body {
  touch-action: manipulation; 
  width:100%;
  height: 85vh;
}

.container-screen {
  margin-left:0.8%;
  border:3px solid black;
  width: 98%;
  height:50%;
  display: flex;
  flex-direction: column;
}
.bank{
 height:5%;
 width:100%;
 background-color:pink

}
#screen{
 width:100%;
 height:95%;
}
.container-box{
 margin-top:17rem;
 display:grid;
 grid-template-columns: repeat(8, 1fr);
 grid-template-rows:100px 100px;
 grid-gap: 10px;
 font-size:2px;
 width:100%;
 height:auto;
font-size:10em;

}
.boxinput{
 box-sizing:border-box;
 max-width:100%;
 font-size:0.5em;
 align-items:center;
 text-align:center;
 border-radius:0.1em;
 width:100%;
 justify-content:center;
}
.container {
  border:none;
  width: 100%;
  height: 50%;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(4, 1fr);
  grid-gap: 10px;
}

.box {
  font-size: 10em;
}
.container > button {
 display:flex;
 font-size:5rem;
 border : 1px solid black;
 text-align: center;
 justify-content:center;
 align-items:center;
}
.cancel {
  grid-column: 4;
  grid-row: 1;
}

.clear {
  grid-column: 4;
  grid-row: 2;
}

.enter {
  grid-column: 4;
  grid-row: 3;
}

.zero {
 
  grid-column: 2;
  grid-row: 4;
}
.alert{
 opacity:0;
 transform:translateY(-130%);
 transition: transform 0.3s ease-in-out, opacity 0.3s ease-in-out;
 display:flex;
 margin-left:10%;
 margin-top:4%;
 background-color:yellow;
 position:absolute;
 z-index:1;
 height:10%;
 width:80%;
 border-radius:5em;
}

.alert.down{

 transform:translateY(60%);
 opacity:1;
}

.alert span {
 display:flex;
 text-align:center;
 align-items:center;
 margin-left:2%;
 font-size:2em;
}
.alert img{
 
 max-height:100%;
 max-width:100%;

}
</style>
</head>
<body>

<div class="alert">
<img src="alert.png" alt="">
<span>	
</span>
</div>
 <div class="container-screen">
  <div class="bank"></div>
    <div id="screen">
     <form class="container-box" method="POST" action="data_numberCard.php">
    <input class="boxinput" type="number" for="input1" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input2" name="number_atm[]" readonly >
    <input class="boxinput" type="number" for="input3" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input4" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input5" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input6" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input7" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input8" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input9" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input10" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input11" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input12" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input13" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input14" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input15" name="number_atm[]" readonly>
    <input class="boxinput" type="number" for="input16" name="number_atm[]" readonly>

    </form>
  </div>
 </div>

<div class="container">
 <button class="box">1</button>
 <button class="box">2</button>
 <button class="box">3</button>
 <button class="cancel box">cancel</button>
 <button class="box">4</button>
 <button class="box">5</button>
 <button class="box">6</button>
 <button class="clear box" onclick="boxClear()">clear</button>
 <button class="box">7</button>
 <button class="box">8</button>
 <button class="box">9</button>
 <button class="enter box">Enter</button>
 <button class="zero box">0</button>
</div>

<script>


const angka = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];
const bahaya = document.querySelector("span");
const enter = document.querySelector(".enter");
const form = document.querySelector("form");
const warning = document.querySelector(".alert");
const box = document.querySelectorAll('.box');
const boxInput = document.querySelectorAll('.boxinput'); // Perbaikan: Menggunakan ".boxinput" daripada ".input"
let index = 0;



const allHaveTextContent = Array.from(boxInput).every(element => element.textContent.trim() !== '');

box.forEach(item => {
  item.addEventListener('click', () => {
  
  
  if (item.textContent === 'cancel') { // Perbaikan: Menggunakan "textContent" daripada "value"
      if (index == 0) {
        boxInput[0].value = ""; // Perbaikan: Menggunakan "value" daripada "textContent"
      } else {
        boxInput[index - 1].value = ""; // Perbaikan: Menggunakan "value" daripada "textContent"
        index--;
      }
    } 
  else if (angka.includes(item.textContent) && index <16) {   
	  boxInput[index].value = item.textContent;                   
	  index++;

 }    

 else if (item.textContent === 'Enter' && index !== 15) { // Perbaikan: Menggunakan "textContent" daripada "value"
 
 eror();
 }


 else if (index > 15) {
form.submit();
    index = 0;
    boxClear();
}


 });  
});
<?php if ($showAlert) { ?>
eror("<?php echo $isi; ?>");
    <?php } ?>

function eror(isi){
	bahaya.textContent=isi;

warning.classList.add("down");                                                          setTimeout(function () {
        warning.classList.remove('down');
      }, 2500);
    }




function boxClear() {
const boxInput = document.querySelectorAll('.boxinput'); // Perbaikan: Menggunakan ".boxinput" daripada ".input"
            boxInput.forEach(box => {
                box.value = "";
});
index=0;
        }
</script>
</body>
</html>

