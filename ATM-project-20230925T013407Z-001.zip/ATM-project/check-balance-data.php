<?php
require_once 'operation_db.php';
use Firebase\JWT\JWT;                                                       
use Firebase\JWT\Key;
require_once 'vendor/autoload.php';
$key = 'example_key';
// Menerima permintaan POST
if ($_SERVER["REQUEST_METHOD"] === "GET") {
	// Mengambil data JSON yang dikirimkan dari client
	$data = json_decode(file_get_contents("php://input"), true);
	if (isset($_COOKIE['jwt_cookie'])) {
		$jwt = $_COOKIE['jwt_cookie'];                                                                       
		global $key;                                                                                                                         
		// Mendekode JWT
		try{
			$decoded = JWT::decode($jwt, new Key($key, 'HS256'));
			$num = $decoded -> NUMBER_CARD;
			$data = [
				'NUMBER_CARD' => $num,
			];

			$result = $operation->checkIfExists($data);

			if ($result !== null ){
				try {
					if(isset($result['SALDO'])) {
						$saldo = $result['SALDO'];
						$response = ["message" => "isi saldo : {$saldo}"];                         
						echo json_encode($response);

					}


				} catch (Exception $e) {                                                                                                  $response = array("message" => "Terjadi kesalahan saat memasukkan data: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8
					'));                                                                                                                              echo json_encode($response);
				}
			}


		} catch (Exception $e) {
			$response = array("message" => "Terjadi kesalahan: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
			echo json_encode($response);
		}






	} else {
		// Permintaan bukan POST
		$response = ["message" => "Hanya permintaan POST yang diterima."];
		echo json_encode($response);
	}
}
?>
