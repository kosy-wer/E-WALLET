<?
require_once 'execute_db.php';

class Operation {
    private $executeDb;

    public function __construct(ExecuteDatabase $executeDb) {
        $this->executeDb = $executeDb;
    }

    public function checkIfExists($data) {
        try {
            return $this->executeDb->executeSelect($data);
        } catch (Exception $e) {
            // Handle exceptions
            echo "Error: " . $e->getMessage();
	}
		 
    }

    public function insertDataUser($data){
    
    
    try{
	
	
        $succesInsert = $this->executeDb->executeInsert($data);

    
    } catch (Exception $e) {

    echo "Error: " . $e->getMessage();
    }
    
    
    
    }

    public function updateSaldo($updateData,$conditions,$additionalConditions =""){

    try {
         return $this->executeDb->executeUpdate($updateData, $conditions, $additionalConditions); 
        } catch (Exception $e) {
            $response = array("message" => "Terjadi kesalahan saat memasukkan data: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
            echo json_encode($response);
        }
    
     } 
    }

$operation = new Operation($executeDb);
?>
