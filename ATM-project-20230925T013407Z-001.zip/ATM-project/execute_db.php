<?php

require_once 'connect_db.php';

class ExecuteDatabase {
	private $connections = [];
	private $connectionConfigs = [];

	public function addConnection($name, array $config) {
		$this->connectionConfigs[$name] = $config;
	}

	private function createConnection($config) {
		return new DatabaseConnection(
			$config['host'],
			$config['user'],
			$config['password'],
			$config['database']
		);
	}

	private function getConnection($name) {
		if (!isset($this->connections[$name])) {
			if (!isset($this->connectionConfigs[$name])) {
				throw new Exception("Connection configuration '$name' is not defined.");
			}

			$connectionConfig = $this->connectionConfigs[$name];
			$this->connections[$name] = $this->createConnection($connectionConfig)->connect();
		}

		return $this->connections[$name];
	}

	public function executeInsert( array $data) {
		$columns = implode(', ', array_keys($data));
		$placeholders = implode(', ', array_fill(0, count($data), '?'));

		$query = "INSERT INTO DATA_USER ($columns) VALUES ($placeholders)";

		$this->executeStatement('insert', $query, array_values($data));
	}

	public function executeUpdate($data, $conditions, $additionalConditions = "") {
    $set = [];
    $params = [];

    foreach ($data as $column => $value) {
        // Cek apakah value berisi operasi matematika
        if (strpos($value, "+") !== false || strpos($value, "-") !== false) {
            $set[] = "$column = $column $value";
        } else {
            $set[] = "$column = ?";
            $params[] = $value;
        }
    }

    $where = [];
    foreach ($conditions as $column => $value) {
        $where[] = "$column = ?";
        $params[] = $value;
    }

    $query = "UPDATE DATA_USER SET " . implode(', ', $set) . " WHERE " . implode(' AND ', $where);
    if ($additionalConditions) {
        $query .= " AND " . $additionalConditions;
    }

    $statement = $this->executeStatement('update', $query, $params);

    // Mengembalikan jumlah baris yang terpengaruh oleh operasi UPDATE
    return $statement->affected_rows;
}


	public function executeSelect($conditions = []) {
		// Dasar query
		$query = "SELECT * FROM DATA_USER";

		if (!empty($conditions)) {
			// Membangun klausa WHERE
			$where = [];
			$params = [];
			foreach ($conditions as $column => $value) {
				$where[] = "$column = ?";
				$params[] = $value;
			}
			$query .= " WHERE " . implode(' AND ', $where);
		}

		$statement = $this->executeStatement('select', $query, $params);
		$result = $statement->get_result()->fetch_assoc();
		return $result;
	}

	// ... other methods ...
	private function bindParams($statement, $params) {
		$types = $this->getParamTypes($params);
		$statement->bind_param($types, ...$params);
	}

	private function getParamTypes($params) {
		$types = '';
		foreach ($params as $param) {
			if (is_int($param)) {
				$types .= 'i';  // integer
			} elseif (is_float($param)) {
				$types .= 'd';  // double
			} elseif (is_string($param)) {
				$types .= 's';  // string
			} else {
				$types .= 'b';  // blob and unknown
			}
		}
		return $types;
	}

	private function executeStatement($connectionName, $query, $params) {
		$connection = $this->getConnection($connectionName);
		$statement = $connection->prepare($query);
		$this->bindParams($statement, $params);

		try {
			$statement->execute();
			return $statement;
		} catch (Exception $e) {
			// Handle exception here or throw it
			throw $e;
		}
	}

	// ... other methods ...

	public function closeConnections() {
		foreach ($this->connections as $connection) {
			$connection->close();
		}
	}

	// Destructor function
	public function __destruct() {
		$this->closeConnections();
	}
}





$executeDb = new ExecuteDatabase();

$executeDb->addConnection('delete', [
	'host' => $dbHost,
	'user' => $dbUser_delete,
	'password' => $dbPass_delete,
	'database' => $dbName
]);
$executeDb->addConnection('update', [
	'host' => $dbHost,
	'user' => $dbUser_update,
	'password' => $dbPass_update,
	'database' => $dbName
]);
$executeDb->addConnection('insert', [
	'host' => $dbHost,
	'user' => $dbUser_insert,
	'password' => $dbPass_insert,
	'database' => $dbName
]);
$executeDb->addConnection('select', [
	'host' => $dbHost,
	'user' => $dbUser_select,
	'password' => $dbPass_select,
	'database' => $dbName
]);



/*$updateData = [
    'SALDO' => '+400'
];

$conditions = [
    'ID' => 2
];

$additionalConditions = "SALDO >120";

$executeDb->executeUpdate($updateData, $conditions, $additionalConditions);
 */


?>
