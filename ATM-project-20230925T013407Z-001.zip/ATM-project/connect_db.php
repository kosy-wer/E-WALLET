<?php
class DatabaseConnection {
    private $host;
    private $user;
    private $password;
    private $database;

    public function __construct($host, $user, $password, $database) {
        $this->host = $host;
        $this->user = $user;
        $this->password = $password;
        $this->database = $database;
    }

    public function connect() {
        return new mysqli($this->host, $this->user, $this->password, $this->database);
    }
}

// Konfigurasi database
$dbName = 'ATM';
$dbHost = '127.0.0.1';

$dbUser_insert = 'insert_user';
$dbPass_insert = 'UNMATCHED588';

$dbUser_update = 'update_user';
$dbPass_update = 'UNMATCHED589';

$dbUser_delete = 'delete_user';
$dbPass_delete = 'UNMATCHED5810';

$dbUser_select = 'select_user';
$dbPass_select = 'UNMATCHED5811';



// Inisialisasi koneksi
?>
