<?php

// Mengimpor pustaka JWT yang diinstal melalui Composer
require_once 'vendor/autoload.php';
// Menerima data dari request POST dan mengurai data JSON yang dikirim
use Firebase\JWT\JWT;
use Firebase\JWT\Key;



// Periksa apakah cookie dengan nama "jwt_cookie" ada
if (!isset( $_COOKIE['jwt_cookie'])){

header("Location:atm.php");
exit;
}
try {

    $jwt = $_COOKIE['jwt_cookie'];
    // Ganti 'example_key' dengan kunci rahasia Anda
    $key ='example_key';

    // Decode JWT untuk mendapatkan payload
     $decoded = JWT::decode($jwt, new Key($key, 'HS256'));
    
    // Mengambil nilai 'numATM' dari payload
     $url = $decoded->url;
 if( $decoded->exp < time()){
   	 

	 header("Location:atm.php");
	 exit;
 }   
 else if($url == "main-menu"){

	 header("Location:{$url}.php");
	 exit;
 } 
} catch (Exception $e) {
    // Tangani jika terjadi kesalahan
    echo 'Error: ' . $e->getMessage();
 }

//cek query ada rspon tidak dari server
$showAlert = false;                                         
if (isset($_GET['correct_pin'])) {
    $isi = $_GET['correct_pin'];
$showAlert = true;                                                                                   
}
//cek query ada rspon tidak dari server
if (isset($_GET['message'])) {
    $isi = $_GET['message'];
$showAlert = true;

}

?>
<!DOCTYPE html>
<html>
<head>
<style>
* {
  margin: 0;
  padding: 0;
}

body {
  touch-action: manipulation; 
  width:100%;
  height: 85vh;
}

.container-screen {
  margin-left:0.8%;
  border:3px solid black;
  width: 98%;
  height:50%;
  display: flex;
  flex-direction: column;
}
.bank{
 height:5%;
 width:100%;
 background-color:pink

}
#screen{
 width:100%;
 height:95%;
}
.container-box{
 margin-top:17rem;
 display:grid;
 grid-template-columns: repeat(8, 1fr);
 grid-template-rows:100px 100px;
 grid-gap: 10px;
 font-size:2px;
 width:100%;
 height:auto;
font-size:10em;
 display:flex;
 justify-content:center;
 align-items:center;

}
.boxinput{
 margin:0 2%;
 box-sizing:border-box;
 max-width:100%;
 font-size:0.5em;
 align-items:center;
 text-align:center;
 border-radius:0.1em;
 width:20%;
 justify-content:space-around;
}
.container {
  border:none;
  width: 100%;
  height: 50%;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(4, 1fr);
  grid-gap: 10px;
}

.box {
  font-size: 10em;
}
.container > button {
 display:flex;
 font-size:5rem;
 border : 1px solid black;
 text-align: center;
 justify-content:center;
 align-items:center;
}
.cancel {
  grid-column: 4;
  grid-row: 1;
}

.clear {
  grid-column: 4;
  grid-row: 2;
}

.enter {
  grid-column: 4;
  grid-row: 3;
}

.zero {
 
  grid-column: 2;
  grid-row: 4;
}
.alert{
 opacity:0;
 transform:translateY(-130%);
 transition: transform 0.3s ease-in-out, opacity 0.3s ease-in-out;
 display:flex;
 margin-left:10%;
 margin-top:4%;
 background-color:yellow;
 position:absolute;
 z-index:1;
 height:10%;
 width:80%;
 border-radius:5em;
}

.alert.down{

 transform:translateY(60%);
 opacity:1;
}

.alert span {
 display:flex;
 text-align:center;
 align-items:center;
 margin-left:2%;
 font-size:2em;
}
.alert img{
 
 max-height:100%;
 max-width:100%;

}
</style>
</head>
<body>

<div class="alert">
<img src="alert.png" alt="">
<span>pin harus penuh
</span>
</div>
 <div class="container-screen">
  <div class="bank"></div>
    <div id="screen">
     <form class="container-box" method="POST" action="data_pin.php">
    <input class="boxinput" type="number" for="input1" name="pin[]" readonly>
    <input class="boxinput" type="number" for="input2" name="pin[]" readonly >
    <input class="boxinput" type="number" for="input3" name="pin[]" readonly>
    <input class="boxinput" type="number" for="input4" name="pin[]" readonly>

    </form>
  </div>
 </div>

<div class="container">
 <button class="box">1</button>
 <button class="box">2</button>
 <button class="box">3</button>
 <button class="cancel box">cancel</button>
 <button class="box">4</button>
 <button class="box">5</button>
 <button class="box">6</button>
 <button class="clear box" onclick="boxClear()">clear</button>
 <button class="box">7</button>
 <button class="box">8</button>
 <button class="box">9</button>
 <button class="enter box">Enter</button>
 <button class="zero box">0</button>
</div>

<script>


const angka = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];

const bank = document.querySelector(".bank");

const enter = document.querySelector(".enter");
const bahaya = document.querySelector("span");
const form = document.querySelector("form");
const warning = document.querySelector(".alert");
const box = document.querySelectorAll('.box');
const screen = document.getElementById('screen');
const boxInput = document.querySelectorAll('.boxinput'); // Perbaikan: Menggunakan ".boxinput" daripada ".input"
let index = 0;



const allHaveTextContent = Array.from(boxInput).every(element => element.textContent.trim() !== '');

box.forEach(item => {
  item.addEventListener('click', () => {
  
  
  if (item.textContent === 'cancel') { // Perbaikan: Menggunakan "textContent" daripada "value"
      if (index == 0) {
        boxInput[0].value = ""; // Perbaikan: Menggunakan "value" daripada "textContent"
      } else {
        boxInput[index - 1].value = ""; // Perbaikan: Menggunakan "value" daripada "textContent"
        index--;
      }
    } 
  else if (angka.includes(item.textContent) && index < 4) {   
	  boxInput[index].value = item.textContent;                   
	  index++;
  if(index == 4){
  form.submit(); 
 }
}    

 else if (item.textContent === 'Enter' && index !== 4) { // Perbaikan: Menggunakan "textContent" daripada "value"
 
 eror();
 }




 });  
});
<?php if ($showAlert) { ?>
eror("<?php echo $isi; ?>");

<?php } ?>

function eror(isi){
        bahaya.textContent=isi;
                                                                                        warning.classList.add("down");                                                          setTimeout(function () {
        warning.classList.remove('down');
      }, 2500);                                                                             }


function boxClear() {
const boxInput = document.querySelectorAll('.boxinput'); // Perbaikan: Menggunakan ".boxinput" daripada ".input"
            boxInput.forEach(box => {
                box.value = "";
});
index=0;
        }
</script>
</body>
</html>

