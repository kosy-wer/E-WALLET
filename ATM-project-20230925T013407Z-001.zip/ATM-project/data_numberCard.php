<?php
require_once 'operation_db.php';
require_once 'vendor/autoload.php';

use Firebase\JWT\JWT;
$key = 'example_key';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $input_values = $_POST["number_atm"];
    $num  = combineValues($input_values);
    $valid = isValidATMNumber($num);

    if (!empty($valid)) {
        $alert = array("warning" => $valid);
        $query = http_build_query($alert);
        header("Location:atm.php?".$query);
        exit();
    } else {
        try {

	 	global $key;	
		$data = [
   		 'NUMBER_CARD' => $num,
		];
	 	if ($operation->checkIfExists($data)){	
                    $alert = array("message" => "Data sudah ada");
                } else {
                    $alert = array("message" => "Data belum  ada.");
		}
		$payload = [
  		  'url' => 'pin',
 		  'iss' => 'http://example.org',
  		  'aud' => 'http://example.com',
  		  'iat' => time(),
 	          'exp' => time() + 3600,
			];
                $query = http_build_query($alert);
                //set nomer atm ke payload
                $payload['NUMBER_CARD'] = $num;
        	
		//buat jwt
                $jwt = JWT::encode($payload, $key, 'HS256');
                setcookie("jwt_cookie", $jwt, time() +60, "pin", false, true);

                // Tidak ada error
                header("Location:pin.php?".$query);
		exit;
        } catch (Exception $e) {
            $response = array("message" => "Terjadi kesalahan: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
            echo json_encode($response);
        }
	
        // Menutup koneksi
        $conn->close();
    }
} else {
    $alert = array("warning" => "method harus post");
    $query = http_build_query($alert);
    header("Location:atm.php?" . $query);
    exit;
}


function isValidATMNumber($num) {
  
    //cek apakah angka  
    if (!is_numeric($num)){
       return "harus angka"; 
    }
    // 1. Cek panjang karakter (16-19 digit)
    $length = strlen($num);
    if ($length < 16 || $length > 19) {
        return "Panjang nomor ATM harus antara 16 hingga 19 digit.";
    }

    // 2. Cek jenis karakter (hanya angka)
    if (!ctype_digit($num)) {
        return "Nomor ATM hanya boleh terdiri dari angka 0-9.";
    }

    // 3. Ceksum menggunakan algoritma Luhn (Modulus 10)
    if (!luhnChecksum($num)) {
        return "Nomor ATM tidak valid.";
    }

    // Semua validasi terpenuhi
    return "";
}

function luhnChecksum($number) {
    $sum = 0;
    $numDigits = strlen($number);
    $parity = $numDigits % 2;

    for ($i = 0; $i < $numDigits; $i++) {
        $digit = intval($number[$i]);

        if ($i % 2 === $parity) {
            $digit *= 2;
            if ($digit > 9) {
                $digit -= 9;
            }
        }

        $sum += $digit;
    }

    return $sum % 10 === 0;
}

function combineValues($input_values) {
    // Menggabungkan semua nilai menjadi satu string dengan pemisah koma
    $combined_value = implode("", $input_values);
    return $combined_value;
}


?>

