<?php
// Mengimpor pustaka JWT yang diinstal melalui Composer
require_once 'vendor/autoload.php';
// Menerima data dari request POST dan mengurai data JSON yang dikirim
use Firebase\JWT\JWT;
use Firebase\JWT\Key;



// Periksa apakah cookie dengan nama "jwt_cookie" ada
if (!isset($_COOKIE['jwt_cookie'])){

	header("Location:atm.php");
	exit;
}

try {

	$jwt = $_COOKIE['jwt_cookie'];
	// Ganti 'example_key' dengan kunci rahasia Anda
	$key = 'example_key';

	// Decode JWT untuk mendapatkan payload
	$decoded = JWT::decode($jwt, new Key($key, 'HS256'));

	// Mengambil nilai 'numATM' dari payload
	$url = $decoded->url;
	if($url !== 'main-menu' || $decoded->exp < time()){

		header("Location:atm.php");
		exit;
	}
} catch (Exception $e) {
	// Tangani jika terjadi kesalahan
	echo 'Error: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html>
<head>
<style>
* {
  margin: 0;
  padding: 0;
}

body {
  touch-action: manipulation; 
  width:100%;
  height: 85vh;
  display: flex;
  justify-content:center;
  align-items:center;
  text-align:center;
  flex-direction: column;
}

body {

 border:1em solid black;
}

.container-screen {
  width: 98%;
  height:50%;
  display: flex;
  flex-direction: column;
}
#screen{
 width:100%;
 height:95%;
}

.info {
 margin-top: 2em;
 font-size:2rem;
 text-align:center;
 height:5%;
}

.container-option{
 width:100%;
 height:95%;
 display:flex;
 justify-content:center;
 align-items:center;
 display: grid;
 grid-template-columns: auto auto;
 gap: 5%;
}

.option{
display:flex;
 justify-content:center;                                                                 align-items:center;
background-color:red;
font-size:1.2em;
width:20em;
height:50%;
}

.depo{
 display:flex;
 justify-content:center;
 align-items:center;
 width:100%;
 height:92%;
}
form {
 height:30%;
 width:100%;
 border:none;
}
form input{
 font-size:5em;
 border:0.1em solid black;
 height:55%;
 width:80%;
}


.container {
  width: 98%;
  height: 50%;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(4, 1fr);
  grid-gap: 10px;
}

.box {
  font-size: 10em;
}
.container > button {
 display:flex;
 font-size:5rem;
 border : 1px solid black;
 text-align: center;
 justify-content:center;
 align-items:center;
}
.cancel {
  grid-column: 4;
  grid-row: 1;
}

.clear {
  grid-column: 4;
  grid-row: 2;
}

.enter {
  grid-column: 4;
  grid-row: 3;
}

.zero {

  grid-column: 2;
  grid-row: 4;
}
.alert{
 opacity:0;
 transform:translateY(-130%);
 transition: transform 0.3s ease-in-out, opacity 0.3s ease-in-out;
 display:flex;
 margin-left:10%;
 margin-top:4%;
 background-color:yellow;
 position:absolute;
 z-index:-1;
 height:10%;
 width:80%;
 border-radius:5em;
}

.alert.down{

 transform:translateY(60%);
 opacity:1;
}

.alert span {
 display:flex;
 text-align:center;
 align-items:center;
 margin-left:2%;
 font-size:2em;
}
.alert img{

 max-height:100%;
 max-width:100%;

}
</style>
</head>
<body>

<div class="alert">
<img src="alert.png" alt="">
<span>pilih salah satu
</span>
</div>
<div class="a"></div>
 <div class="container-screen">
  <div id="screen">
    <div class="info"> &gt; &gt; pilih salah satu option &lt; &lt;</div>
   <div class="container-option">
     <button class="option">with-draw</button>
     <button class="option">deposit</button>
     <button class="option">transfer</button>
     <button class="option">check-balance</button>
   </div>
  </div>
 </div>

<div class="container">
 <button class="box">1</button>
 <button class="box">2</button>
 <button class="box">3</button>
 <button class="cancel box">cancel</button>
 <button class="box">4</button>
 <button class="box">5</button>
 <button class="box">6</button>
 <button class="clear box">clear</button>
 <button class="box">7</button>
 <button class="box">8</button>
 <button class="box">9</button>
 <button class="enter box">Enter</button>
 <button class="zero box">0</button>
</div>

<script>
let setup = [];
const angka = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];
const options = document.querySelectorAll('.option');
const container = document.querySelector(".container-option");
const box = document.querySelectorAll('.box');
const optionSaldo = ["with-draw","deposit","transfer"];
let cek = false;
options.forEach(e => {
e.addEventListener('click', () => {
const isi = e.textContent;


if (optionSaldo.includes(isi)) {
	inputSaldo();

	if(isi == "deposit"){
		setup =["PUT",isi];

	}

	else if(isi == "with-draw"){

		setup =["DELETE",isi];
	}
	else {
		setup =["PATCH",isi];

	} 

}else{
	setup =["GET",isi];
	sendReq(...setup,"");
}



});
});



box.forEach(e => {
e.addEventListener('click', () => {
const val = e.textContent;
if(cek){
	const input = document.querySelector("input");
	if(angka.includes(e.textContent) ){
		input.value+= val;
		const num = input.value.replace(/[^0-9]/g, "");
		const formatted = num === "0" ? num : num.replace(/\B(?=(\d{3})+(?!\d))/g, ".");

		input.value = formatted;    
	}

	else if (val == "clear"){

		input.value ="";

	}


	else if (val == "cancel"){

		if(input.value.length > 0){

			const res = input.value.slice(0,-1);

			input.value =  res;
		}
	}

	else if (val == "Enter" ){


		if(input.value.length > 0){


			let angka = formatAngka(input.value);		

			sendReq(...setup,angka);

		}
	}


}
});
});




function inputSaldo(){

	// Menghapus 2 elemen terakhir
	for (let i = 1; i < options.length; i++) {
		container.removeChild(options[i]);
	}

	//mengganti class container
	container.classList.replace("container-option", "depo");
	//buat tag form dan beri class depo
	const form = document.createElement("form");
	form.className = "depo";

	/*buat tag input dan beri value pada atribute yang diperlu      kan jadikan sebagai child nya from  */ 
	const input = document.createElement("input");
	input.type = "text";
	input.readOnly= true;

	form.appendChild(input);
	//buat form jadi child container untuk option pertama 
	container.replaceChild(form, options[0]);

	cek = true;
}


async function sendReq(method, lok, action) {
	try {
		let options = {
		method: method,
			headers: {
			"Content-Type": "application/json"
	}
	};

		if (method != "GET") {
			// Hanya tambahkan body jika metodenya adalah "POST" atau "PUT"
			options.body = JSON.stringify({ action: action });
		}

		const response = await fetch(lok + "-data.php", options);

		if (!response.ok) {
			throw new Error(`HTTP error! Status: ${response.status}`);
		}

		const data = await response.json();
		if (data && data.message) {
			alert(data.message);
 if(method != "GET"){
	 let confirmation = confirm("Apakah Anda yakin ingin keluar dari halaman ini?");
 
 
if (confirmation) {
	window.location.href = "https://www.google.com"; 
} else {
	menu();
}
 }
		} else {
			alert("Respon tidak ada respon");
		}

	} catch (error) {
		const a = document.querySelector("body");
		console.error(error);
		alert(error);
	}
}


function menu() {
    const form = document.querySelector("form");

    // Hapus form dari container
    container.removeChild(form);

    // Ganti kelas container kembali ke "container-option"
    container.classList.replace("depo","container-option");

    // Ambil kembali referensi ke container setelah mengganti kelasnya


    // Selanjutnya, Anda dapat melanjutkan dengan kode lainnya
    optionSaldo.push("check-balance");
    optionSaldo.forEach(function (teks, index) {
        var newEl = document.createElement("div");
        newEl.textContent = teks;
        newEl.className = "option";

        // Tambahkan elemen dengan teks ke dalam container
        container.appendChild(newEl);
    });
}





function hapusTitik(angka) {
	return angka.replace(/\./g, '');
}

// Mengubah angka dengan format ribuan menjadi angka tanpa titik
function formatAngka(angka) {
	// Menghapus semua titik
	const tanpaTitik = hapusTitik(angka);
	// Mengubah ke angka tanpa format ribuan
	const angkaTanpaFormat = parseInt(tanpaTitik, 10);
	return angkaTanpaFormat;
}
</script>
</body>
</html>
